---
apiVersion: processkit.projectious.work/v1
kind: Migration
metadata:
  id: MIG-20260724_1655-LockBaseline
  created: 2026-07-24 16:55:42+00:00
  updated: '2026-07-26T16:08:29+00:00'
spec:
  source: aibox-lock
  source_url: aibox://lock
  kind: schema-extension
  state: applied
  generated_by: aibox apply
  generated_at: 2026-07-24 16:55:42+00:00
  summary: 'Backfilled previous_selection: 9 addon(s), 28 tool(s), 1 harness(es)'
  started_at: '2026-07-26T16:08:29+00:00'
  applied_at: '2026-07-26T16:08:29+00:00'
  progress_notes:
  - timestamp: '2026-07-26T16:08:29+00:00'
    actor: mcp
    note: Acknowledged aibox.lock previous_selection baseline; no code change required.
---

# Migration MIG-20260724_1655-LockBaseline

`aibox.lock` schema extended in v0.25.6 to record the previously
applied addon-tool and harness selection (DEC-20260508_1515-SilentAsh,
BR-CLEANUP-ARCH item 1). This backfill captures the current selection
as the baseline so the next `aibox apply` can compute a removal diff
when a tool or harness is disabled.

Backfilled previous_selection: 9 addon(s), 28 tool(s), 1 harness(es)

## Backfilled addon selection

- `audio-voice`: alsa-pulse, pulseaudio-utils, sox, sox-pulse
- `cloudflare`: cloudflared
- `git-ui`: gh, lazygit
- `infrastructure`: ansible, opentofu, packer
- `kubernetes`: helm, kubectl, kustomize
- `node`: node, pnpm
- `preview-archive`: chafa, entr, librsvg, mupdf, p7zip, poppler, resvg, timg
- `preview-enhanced`: ffmpeg, ghostscript, rich
- `python`: python, uv

## Backfilled harness selection

- codex

## Next action

Acknowledge with the migration-management skill (`/pk-resume` will
surface it). No code change is required — the next `aibox apply`
will use this baseline automatically.
